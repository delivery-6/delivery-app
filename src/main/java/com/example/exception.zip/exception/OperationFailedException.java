package com.example.exception;

public class OperationFailedException extends CustomException {
    public OperationFailedException(String message) {
        super(message, 500); // HTTP 500: Internal Server Error
    }
}
