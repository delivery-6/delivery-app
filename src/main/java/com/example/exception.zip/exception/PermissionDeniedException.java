package com.example.exception;

public class PermissionDeniedException extends CustomException {
    public PermissionDeniedException(String message) {
        super(message, 403); // HTTP 403: Forbidden
    }
}
