package com.example.exception;

public class ResourceAlreadyExistsException extends CustomException {
    public ResourceAlreadyExistsException(String message) {
        super(message, 409); // HTTP 409: Conflict
    }
}
